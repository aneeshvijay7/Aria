# Mega vROps Latency Dashboard Pack (with Auto-Highlight)

This ZIP contains:
- dashboard.json — Combined mega-dashboard (VM + VirtualDisk + Datastore views) with preconfigured auto-highlighting filters
- README.md — Import instructions and notes

## Import
1. Log in to Aria Operations (vROps)
2. Dashboards -> Actions -> Import
3. Upload `dashboard.json`
4. Edit metric.metricName if needed (use Metrics browser to verify keys)

## Auto-Highlight behavior
- Warning threshold: >= 20 ms (visual style: orange emphasis)
- Critical threshold: >= 50 ms (visual style: red emphasis)
- Non-exceeding series are dimmed to 15% opacity (behavior: dim-others)

You can tweak thresholds and styles after import in widget settings.
